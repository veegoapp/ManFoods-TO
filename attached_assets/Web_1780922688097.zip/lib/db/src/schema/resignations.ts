import { pgTable, text, serial, integer, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const resignationsTable = pgTable("resignations_history", {
  id: serial("id").primaryKey(),
  month: integer("month").notNull(),
  year: integer("year").notNull(),
  employeeId: text("employee_id").notNull(),
  name: text("name").notNull(),
  store: text("store").notNull(),
  jobTitle: text("job_title").notNull(),
  gender: text("gender").notNull().default(""),
  hireDate: date("hire_date"),
  resignationDate: date("resignation_date"),
  payrollGroup: text("payroll_group").notNull().default(""),
  costCenter: text("cost_center").notNull().default(""),
});

export const insertResignationSchema = createInsertSchema(resignationsTable).omit({ id: true });
export type InsertResignation = z.infer<typeof insertResignationSchema>;
export type Resignation = typeof resignationsTable.$inferSelect;
