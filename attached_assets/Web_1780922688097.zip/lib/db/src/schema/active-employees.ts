import { pgTable, text, serial, integer, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const activeEmployeesTable = pgTable("active_employees_history", {
  id: serial("id").primaryKey(),
  month: integer("month").notNull(),
  year: integer("year").notNull(),
  employeeId: text("employee_id").notNull(),
  name: text("name").notNull(),
  store: text("store").notNull(),
  jobTitle: text("job_title").notNull(),
  grade: text("grade").notNull().default(""),
  payrollGroup: text("payroll_group").notNull().default(""),
  costCenter: text("cost_center").notNull().default(""),
  gender: text("gender").notNull().default(""),
  hireDate: date("hire_date"),
});

export const insertActiveEmployeeSchema = createInsertSchema(activeEmployeesTable).omit({ id: true });
export type InsertActiveEmployee = z.infer<typeof insertActiveEmployeeSchema>;
export type ActiveEmployee = typeof activeEmployeesTable.$inferSelect;
