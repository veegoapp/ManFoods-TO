import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const uploadLogsTable = pgTable("upload_logs", {
  id: serial("id").primaryKey(),
  fileType: text("file_type").notNull(),
  fileName: text("file_name").notNull(),
  month: integer("month").notNull(),
  year: integer("year").notNull(),
  uploadDate: timestamp("upload_date", { withTimezone: true }).notNull().defaultNow(),
  uploadedBy: text("uploaded_by").notNull(),
});

export const insertUploadLogSchema = createInsertSchema(uploadLogsTable).omit({ id: true, uploadDate: true });
export type InsertUploadLog = z.infer<typeof insertUploadLogSchema>;
export type UploadLog = typeof uploadLogsTable.$inferSelect;
