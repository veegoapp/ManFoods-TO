import { pgTable, text, serial, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const storeReferenceTable = pgTable("stores_reference_history", {
  id: serial("id").primaryKey(),
  month: integer("month").notNull(),
  year: integer("year").notNull(),
  storeName: text("store_name").notNull(),
  storeLeader: text("store_leader").notNull().default(""),
  operationConsultant: text("operation_consultant").notNull().default(""),
  operationManager: text("operation_manager").notNull().default(""),
});

export const insertStoreReferenceSchema = createInsertSchema(storeReferenceTable).omit({ id: true });
export type InsertStoreReference = z.infer<typeof insertStoreReferenceSchema>;
export type StoreReference = typeof storeReferenceTable.$inferSelect;
