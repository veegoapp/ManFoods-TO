import { useState } from "react";
import { 
  useGetDashboardKpis, getGetDashboardKpisQueryKey,
  useGetTurnoverByJobTitle, getGetTurnoverByJobTitleQueryKey,
  useGetTurnoverByTenure, getGetTurnoverByTenureQueryKey,
  useGetGenderBreakdown, getGetGenderBreakdownQueryKey,
  useGetAvailablePeriods, getGetAvailablePeriodsQueryKey,
  useListStores, getListStoresQueryKey
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, RadialBarChart, RadialBar, Legend, PieChart, Pie, Cell } from "recharts";
import { Sparkles, Users, UserMinus, UserPlus, TrendingUp, Loader2 } from "lucide-react";

export function DashboardView({ isAdmin = false }: { isAdmin?: boolean }) {
  const [selectedMonth, setSelectedMonth] = useState<number | undefined>();
  const [selectedYear, setSelectedYear] = useState<number | undefined>();
  const [selectedStore, setSelectedStore] = useState<string | "all">("all");

  const { data: periods } = useGetAvailablePeriods({
    query: { queryKey: getGetAvailablePeriodsQueryKey() },
  });

  // Default to latest period if none selected
  const activeMonth = selectedMonth ?? periods?.[0]?.month;
  const activeYear = selectedYear ?? periods?.[0]?.year;
  const activeStore = selectedStore === "all" ? undefined : selectedStore;

  const storesParams = { month: activeMonth, year: activeYear };
  const { data: storesData } = useListStores(storesParams, {
    query: {
      queryKey: getListStoresQueryKey(storesParams),
      enabled: !!activeMonth && !!activeYear,
    },
  });
  const stores = storesData?.map((s) => s.storeName) ?? [];

  const params = { month: activeMonth, year: activeYear, store: activeStore };

  const { data: kpis, isLoading: kpisLoading } = useGetDashboardKpis(params, {
    query: { enabled: !!activeMonth && !!activeYear, queryKey: getGetDashboardKpisQueryKey(params) },
  });

  const { data: jobTitleData } = useGetTurnoverByJobTitle(params, {
    query: { enabled: !!activeMonth && !!activeYear, queryKey: getGetTurnoverByJobTitleQueryKey(params) },
  });

  const { data: tenureData } = useGetTurnoverByTenure(params, {
    query: { enabled: !!activeMonth && !!activeYear, queryKey: getGetTurnoverByTenureQueryKey(params) },
  });

  const genderParams = { month: activeMonth, year: activeYear !== undefined ? String(activeYear) : undefined, store: activeStore };
  const { data: genderData } = useGetGenderBreakdown(genderParams, {
    query: { enabled: !!activeMonth && !!activeYear, queryKey: getGetGenderBreakdownQueryKey(genderParams) },
  });

  const COLORS = ['hsl(var(--chart-1))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))', 'hsl(var(--chart-5))'];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{isAdmin ? "Global Analytics" : "Dashboard"}</h1>
          <p className="text-muted-foreground">Workforce intelligence and turnover metrics.</p>
        </div>
        
        <div className="flex gap-2 w-full sm:w-auto">
          <Select 
            value={activeMonth && activeYear ? `${activeMonth}-${activeYear}` : ""} 
            onValueChange={(val) => {
              const [m, y] = val.split('-');
              setSelectedMonth(Number(m));
              setSelectedYear(Number(y));
            }}
          >
            <SelectTrigger className="w-[180px] bg-card">
              <SelectValue placeholder="Select Period" />
            </SelectTrigger>
            <SelectContent>
              {periods?.map((p) => (
                <SelectItem key={`${p.month}-${p.year}`} value={`${p.month}-${p.year}`}>
                  {new Date(p.year, p.month - 1).toLocaleString('default', { month: 'long', year: 'numeric' })}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={selectedStore} onValueChange={setSelectedStore}>
            <SelectTrigger className="w-[200px] bg-card">
              <SelectValue placeholder="All Stores" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Stores</SelectItem>
              {stores.map((s) => (
                <SelectItem key={s} value={s}>{s}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {kpisLoading ? (
        <div className="h-40 flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Headcount</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{kpis?.totalHeadcount || 0}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">New Hires</CardTitle>
              <UserPlus className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-emerald-500">{kpis?.newHires || 0}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Resignations</CardTitle>
              <UserMinus className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-destructive">{kpis?.totalResignations || 0}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Turnover Rate</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{kpis?.turnoverRate ? kpis.turnoverRate.toFixed(1) : 0}%</div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* AI Insights Placeholder */}
      <Card className="bg-gradient-to-r from-primary/10 via-card to-card border-primary/20">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-primary/20 rounded-lg">
              <Sparkles className="h-5 w-5 text-primary" />
            </div>
            <CardTitle>AI Insights</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            Gemini AI insights will appear here. Connect your Google AI Studio API key to enable smart recommendations.
          </p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Turnover by Job Title</CardTitle>
            <CardDescription>Resignations grouped by role</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            {jobTitleData && jobTitleData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={jobTitleData} layout="vertical" margin={{ top: 5, right: 30, left: 40, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="hsl(var(--border))" />
                  <XAxis type="number" hide />
                  <YAxis dataKey="label" type="category" axisLine={false} tickLine={false} tick={{fill: 'hsl(var(--muted-foreground))'}} />
                  <RechartsTooltip cursor={{fill: 'hsl(var(--muted))'}} contentStyle={{backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', color: 'hsl(var(--foreground))'}} />
                  <Bar dataKey="value" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} barSize={20} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-muted-foreground text-sm">No data available</div>
            )}
          </CardContent>
        </Card>

        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Turnover by Tenure</CardTitle>
            <CardDescription>Duration of employment before resignation</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            {tenureData && tenureData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={tenureData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                  <XAxis dataKey="label" axisLine={false} tickLine={false} tick={{fill: 'hsl(var(--muted-foreground))'}} />
                  <YAxis hide />
                  <RechartsTooltip cursor={{fill: 'hsl(var(--muted))'}} contentStyle={{backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', color: 'hsl(var(--foreground))'}} />
                  <Bar dataKey="value" fill="hsl(var(--chart-2))" radius={[4, 4, 0, 0]} barSize={40} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-muted-foreground text-sm">No data available</div>
            )}
          </CardContent>
        </Card>

        <Card className="col-span-1 lg:col-span-2">
          <CardHeader>
            <CardTitle>Gender Breakdown</CardTitle>
            <CardDescription>Active workforce gender distribution</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            {genderData && genderData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={genderData}
                    cx="50%"
                    cy="50%"
                    innerRadius={80}
                    outerRadius={110}
                    paddingAngle={2}
                    dataKey="value"
                    nameKey="label"
                  >
                    {genderData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <RechartsTooltip contentStyle={{backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', color: 'hsl(var(--foreground))'}} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-muted-foreground text-sm">No data available</div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
