import { Link, useLocation } from "wouter";
import { useLogout } from "@workspace/api-client-react";
import {
  LayoutDashboard,
  UploadCloud,
  PieChart,
  Users,
  FileText,
  LogOut,
  User as UserIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import type { AuthUser } from "@workspace/api-client-react";

export function Layout({ children, user }: { children: React.ReactNode; user: AuthUser }) {
  const [location] = useLocation();
  const logout = useLogout();

  const handleLogout = () => {
    logout.mutate(undefined, {
      onSuccess: () => {
        window.location.href = "/login";
      },
    });
  };

  const navItems = user.role.startsWith("Admin")
    ? [
        { href: "/admin/analytics", label: "Global Analytics", icon: LayoutDashboard },
        { href: "/admin/uploads", label: "Data Management", icon: UploadCloud },
        { href: "/admin/turnover", label: "Turnover Analysis", icon: PieChart },
        { href: "/admin/users", label: "Users", icon: Users },
        { href: "/admin/reports", label: "Reports", icon: FileText },
      ]
    : [{ href: "/dashboard", label: "Dashboard", icon: LayoutDashboard }];

  return (
    <div className="min-h-screen bg-background text-foreground flex">
      {/* Sidebar */}
      <aside className="w-64 border-r border-border bg-card flex flex-col fixed inset-y-0 left-0">
        <div className="h-16 flex items-center px-6 border-b border-border">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded bg-primary flex items-center justify-center font-bold text-primary-foreground">
              M
            </div>
            <span className="font-bold text-lg tracking-tight">Manfoods</span>
          </div>
        </div>
        <nav className="flex-1 py-6 px-3 space-y-1">
          {navItems.map((item) => {
            const isActive = location === item.href;
            return (
              <Link key={item.href} href={item.href} className="block">
                <Button
                  variant={isActive ? "secondary" : "ghost"}
                  className="w-full justify-start gap-3 px-3"
                >
                  <item.icon className="w-4 h-4" />
                  {item.label}
                </Button>
              </Link>
            );
          })}
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 ml-64 flex flex-col min-h-screen">
        {/* Topbar */}
        <header className="h-16 border-b border-border bg-card/50 backdrop-blur sticky top-0 z-10 flex items-center justify-between px-8">
          <div className="flex-1" />
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3">
              <Avatar className="h-8 w-8 bg-primary/20 text-primary">
                <AvatarFallback>
                  <UserIcon className="h-4 w-4" />
                </AvatarFallback>
              </Avatar>
              <div className="flex flex-col">
                <span className="text-sm font-medium leading-none">{user.email}</span>
                <span className="text-xs text-muted-foreground">{user.role.replace("_", " ")}</span>
              </div>
            </div>
            <div className="w-px h-6 bg-border mx-2" />
            <Button variant="ghost" size="icon" onClick={handleLogout} title="Sign Out">
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 p-8">{children}</div>
      </main>
    </div>
  );
}
