import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";
import NotFound from "@/pages/not-found";
import Login from "@/pages/login";
import Dashboard from "@/pages/dashboard";
import AdminAnalytics from "@/pages/admin-analytics";
import AdminUploads from "@/pages/admin-uploads";
import AdminTurnover from "@/pages/admin-turnover";
import AdminUsers from "@/pages/admin-users";
import AdminReports from "@/pages/admin-reports";
import { Layout } from "@/components/layout";
import { useEffect } from "react";
import { Loader2 } from "lucide-react";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

function AuthGuard({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const isLoginPage = location === "/login";

  const { data: user, isLoading, isError } = useGetMe({
    query: {
      queryKey: getGetMeQueryKey(),
      retry: false,
    },
  });

  useEffect(() => {
    if (!isLoading) {
      if (isError || !user) {
        if (!isLoginPage) setLocation("/login");
      } else {
        if (isLoginPage || location === "/") {
          if (user.role === "Admin_Full" || user.role === "Admin_Read") {
            setLocation("/admin/analytics");
          } else {
            setLocation("/dashboard");
          }
        }
      }
    }
  }, [user, isLoading, isError, location, isLoginPage, setLocation]);

  if (isLoginPage) {
    return <>{children}</>;
  }

  if (isLoading) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) return null;

  return <Layout user={user}>{children}</Layout>;
}

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/admin/analytics" component={AdminAnalytics} />
      <Route path="/admin/uploads" component={AdminUploads} />
      <Route path="/admin/turnover" component={AdminTurnover} />
      <Route path="/admin/users" component={AdminUsers} />
      <Route path="/admin/reports" component={AdminReports} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <AuthGuard>
            <Router />
          </AuthGuard>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
