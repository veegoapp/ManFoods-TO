import { DashboardView } from "@/components/dashboard-view";

export default function AdminAnalytics() {
  return <DashboardView isAdmin={true} />;
}
