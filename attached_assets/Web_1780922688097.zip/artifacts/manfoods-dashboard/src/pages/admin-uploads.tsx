import { useState } from "react";
import { useListUploadLogs, getListUploadLogsQueryKey, useDeleteUploadLog, useGetAvailablePeriods } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Upload, Trash2, FileSpreadsheet } from "lucide-react";

export default function AdminUploads() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [uploading, setUploading] = useState<string | null>(null);

  const { data: logs, isLoading } = useListUploadLogs({ query: { queryKey: getListUploadLogsQueryKey() } });
  const { data: periods } = useGetAvailablePeriods();
  const deleteLog = useDeleteUploadLog();

  const [month, setMonth] = useState<string>(String(new Date().getMonth() + 1));
  const [year, setYear] = useState<string>(String(new Date().getFullYear()));
  const [files, setFiles] = useState<Record<string, File | null>>({
    'active-employees': null,
    'resignations': null,
    'store-reference': null
  });

  const handleFileChange = (type: string, file: File | null) => {
    setFiles(prev => ({ ...prev, [type]: file }));
  };

  const handleUpload = async (type: string, endpoint: string) => {
    const file = files[type];
    if (!file) return;

    setUploading(type);
    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('month', month);
      formData.append('year', year);

      const res = await fetch(`${import.meta.env.BASE_URL}api/uploads/${endpoint}`, {
        method: 'POST',
        body: formData,
      });

      if (!res.ok) {
        throw new Error(await res.text());
      }

      toast({ title: "Upload successful", description: `${file.name} uploaded successfully.` });
      setFiles(prev => ({ ...prev, [type]: null }));
      
      // Clear input file
      const fileInput = document.getElementById(`file-${type}`) as HTMLInputElement;
      if (fileInput) fileInput.value = '';

      queryClient.invalidateQueries({ queryKey: getListUploadLogsQueryKey() });
    } catch (error: any) {
      toast({ variant: "destructive", title: "Upload failed", description: error.message || "An error occurred during upload." });
    } finally {
      setUploading(null);
    }
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this upload log? The data will not be removed from the database, only the log entry.")) {
      deleteLog.mutate({ id }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListUploadLogsQueryKey() });
          toast({ title: "Log deleted" });
        },
        onError: () => toast({ variant: "destructive", title: "Error deleting log" })
      });
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Data Management</h1>
        <p className="text-muted-foreground">Upload and manage source data files.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="col-span-1 md:col-span-3">
          <CardHeader>
            <CardTitle>Period Selection</CardTitle>
            <CardDescription>Select the target month and year for the data you are uploading.</CardDescription>
          </CardHeader>
          <CardContent className="flex gap-4">
            <div className="space-y-2">
              <Label>Month</Label>
              <Select value={month} onValueChange={setMonth}>
                <SelectTrigger className="w-[180px] bg-card">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Array.from({ length: 12 }).map((_, i) => (
                    <SelectItem key={i + 1} value={String(i + 1)}>
                      {new Date(2000, i).toLocaleString('default', { month: 'long' })}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Year</Label>
              <Select value={year} onValueChange={setYear}>
                <SelectTrigger className="w-[180px] bg-card">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[2023, 2024, 2025, 2026].map(y => (
                    <SelectItem key={y} value={String(y)}>{y}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <UploadCard 
          title="Active Employees" 
          description="Upload current workforce data" 
          type="active-employees"
          endpoint="active-employees"
          file={files['active-employees']}
          onChange={(f: File | null) => handleFileChange('active-employees', f)}
          onUpload={() => handleUpload('active-employees', 'active-employees')}
          isUploading={uploading === 'active-employees'}
        />
        <UploadCard 
          title="Resignations" 
          description="Upload attrition data" 
          type="resignations"
          endpoint="resignations"
          file={files['resignations']}
          onChange={(f: File | null) => handleFileChange('resignations', f)}
          onUpload={() => handleUpload('resignations', 'resignations')}
          isUploading={uploading === 'resignations'}
        />
        <UploadCard 
          title="Store Reference" 
          description="Upload store hierarchy mapping" 
          type="store-reference"
          endpoint="store-reference"
          file={files['store-reference']}
          onChange={(f: File | null) => handleFileChange('store-reference', f)}
          onUpload={() => handleUpload('store-reference', 'store-reference')}
          isUploading={uploading === 'store-reference'}
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Upload History</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center p-8"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>File Type</TableHead>
                  <TableHead>File Name</TableHead>
                  <TableHead>Period</TableHead>
                  <TableHead>Uploaded By</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {logs?.map((log) => (
                  <TableRow key={log.id}>
                    <TableCell className="font-medium whitespace-nowrap">
                      {new Date(log.uploadDate).toLocaleString()}
                    </TableCell>
                    <TableCell className="capitalize">{log.fileType.replace('-', ' ')}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <FileSpreadsheet className="h-4 w-4 text-muted-foreground" />
                        {log.fileName}
                      </div>
                    </TableCell>
                    <TableCell>{log.month}/{log.year}</TableCell>
                    <TableCell>{log.uploadedBy}</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="icon" onClick={() => handleDelete(log.id)} className="text-destructive hover:bg-destructive/10 hover:text-destructive">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
                {logs?.length === 0 && (
                  <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No upload history found</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function UploadCard({ title, description, type, file, onChange, onUpload, isUploading }: any) {
  return (
    <Card className="flex flex-col">
      <CardHeader>
        <CardTitle className="text-lg">{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col justify-between space-y-4">
        <div className="space-y-2">
          <Input 
            id={`file-${type}`}
            type="file" 
            accept=".xlsx,.xls,.csv" 
            onChange={(e) => onChange(e.target.files?.[0] || null)}
            className="cursor-pointer bg-background"
          />
        </div>
        <Button 
          className="w-full" 
          disabled={!file || isUploading} 
          onClick={onUpload}
        >
          {isUploading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Upload className="mr-2 h-4 w-4" />}
          {isUploading ? "Uploading..." : "Upload File"}
        </Button>
      </CardContent>
    </Card>
  );
}
