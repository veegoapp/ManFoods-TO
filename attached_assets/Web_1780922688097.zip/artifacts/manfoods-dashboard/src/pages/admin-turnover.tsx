import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Construction } from "lucide-react";

export default function AdminTurnover() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Turnover Analysis</h1>
        <p className="text-muted-foreground">Deep dive into retention metrics and trends.</p>
      </div>
      
      <Card className="border-dashed border-2 bg-transparent">
        <CardContent className="flex flex-col items-center justify-center h-[400px] text-center space-y-4">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center">
            <Construction className="h-8 w-8 text-muted-foreground" />
          </div>
          <CardTitle className="text-xl">Coming Soon</CardTitle>
          <CardDescription className="max-w-md">
            Advanced turnover analysis, cohort tracking, and predictive modeling will be available in the next platform update.
          </CardDescription>
        </CardContent>
      </Card>
    </div>
  );
}
