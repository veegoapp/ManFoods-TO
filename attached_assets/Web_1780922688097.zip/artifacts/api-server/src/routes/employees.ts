import { Router } from "express";
import { db, activeEmployeesTable, resignationsTable, storeReferenceTable } from "@workspace/db";
import { eq, and, sql } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";

const router = Router();

async function getAccessibleStores(role: string, assignedName: string | null, month?: number, year?: number): Promise<string[] | null> {
  if (role === "Admin_Full" || role === "Admin_Read") return null;
  const conditions = [];
  if (month) conditions.push(eq(storeReferenceTable.month, month));
  if (year) conditions.push(eq(storeReferenceTable.year, year));
  if (role === "Operation_Manager" && assignedName) {
    conditions.push(eq(storeReferenceTable.operationManager, assignedName));
  } else if (role === "Operation_Consultant" && assignedName) {
    conditions.push(eq(storeReferenceTable.operationConsultant, assignedName));
  }
  const results = conditions.length > 0
    ? await db.select({ storeName: storeReferenceTable.storeName }).from(storeReferenceTable).where(and(...conditions))
    : await db.select({ storeName: storeReferenceTable.storeName }).from(storeReferenceTable);
  return results.map((r) => r.storeName);
}

router.get("/employees", requireAuth, async (req, res) => {
  const month = req.query.month ? parseInt(req.query.month as string) : undefined;
  const year = req.query.year ? parseInt(req.query.year as string) : undefined;
  const store = req.query.store as string | undefined;
  const { role, assignedName } = req.session as { role: string; assignedName: string | null };

  const accessibleStores = await getAccessibleStores(role, assignedName ?? null, month, year);

  const conditions = [];
  if (month) conditions.push(eq(activeEmployeesTable.month, month));
  if (year) conditions.push(eq(activeEmployeesTable.year, year));
  if (store) conditions.push(eq(activeEmployeesTable.store, store));
  else if (accessibleStores && accessibleStores.length > 0) {
    conditions.push(sql`${activeEmployeesTable.store} = ANY(${accessibleStores})`);
  }

  const employees = conditions.length > 0
    ? await db.select().from(activeEmployeesTable).where(and(...conditions))
    : await db.select().from(activeEmployeesTable);

  res.json(employees.map((e) => ({
    id: e.id,
    employeeId: e.employeeId,
    name: e.name,
    store: e.store,
    jobTitle: e.jobTitle,
    grade: e.grade,
    payrollGroup: e.payrollGroup,
    costCenter: e.costCenter,
    gender: e.gender,
    hireDate: e.hireDate ?? null,
    month: e.month,
    year: e.year,
  })));
});

router.get("/resignations", requireAuth, async (req, res) => {
  const month = req.query.month ? parseInt(req.query.month as string) : undefined;
  const year = req.query.year ? parseInt(req.query.year as string) : undefined;
  const store = req.query.store as string | undefined;
  const { role, assignedName } = req.session as { role: string; assignedName: string | null };

  const accessibleStores = await getAccessibleStores(role, assignedName ?? null, month, year);

  const conditions = [];
  if (month) conditions.push(eq(resignationsTable.month, month));
  if (year) conditions.push(eq(resignationsTable.year, year));
  if (store) conditions.push(eq(resignationsTable.store, store));
  else if (accessibleStores && accessibleStores.length > 0) {
    conditions.push(sql`${resignationsTable.store} = ANY(${accessibleStores})`);
  }

  const resignations = conditions.length > 0
    ? await db.select().from(resignationsTable).where(and(...conditions))
    : await db.select().from(resignationsTable);

  res.json(resignations.map((r) => ({
    id: r.id,
    employeeId: r.employeeId,
    name: r.name,
    store: r.store,
    jobTitle: r.jobTitle,
    gender: r.gender,
    hireDate: r.hireDate ?? null,
    resignationDate: r.resignationDate ?? null,
    payrollGroup: r.payrollGroup,
    costCenter: r.costCenter,
    month: r.month,
    year: r.year,
  })));
});

export default router;
