import { Router } from "express";
import { db, storeReferenceTable } from "@workspace/db";
import { eq, and, sql } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";

const router = Router();

router.get("/stores", requireAuth, async (req, res) => {
  const month = req.query.month ? parseInt(req.query.month as string) : undefined;
  const year = req.query.year ? parseInt(req.query.year as string) : undefined;
  const { role, assignedName } = req.session as { role: string; assignedName: string | null };

  const conditions = [];
  if (month) conditions.push(eq(storeReferenceTable.month, month));
  if (year) conditions.push(eq(storeReferenceTable.year, year));

  if (role === "Operation_Manager" && assignedName) {
    conditions.push(eq(storeReferenceTable.operationManager, assignedName));
  } else if (role === "Operation_Consultant" && assignedName) {
    conditions.push(eq(storeReferenceTable.operationConsultant, assignedName));
  }

  const results = conditions.length > 0
    ? await db.select().from(storeReferenceTable).where(and(...conditions)).orderBy(storeReferenceTable.storeName)
    : await db.select().from(storeReferenceTable).orderBy(storeReferenceTable.storeName);

  res.json(results);
});

export default router;
