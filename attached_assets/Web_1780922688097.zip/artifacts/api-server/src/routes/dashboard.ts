import { Router } from "express";
import { db, activeEmployeesTable, resignationsTable, storeReferenceTable } from "@workspace/db";
import { eq, and, sql } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";

const router = Router();

function getStoreFilter(req: ReturnType<typeof Router>["use"] extends never ? never : InstanceType<typeof Object>, role: string, assignedName: string | null) {
  return { role, assignedName };
}

async function getAccessibleStores(role: string, assignedName: string | null, month?: number, year?: number): Promise<string[]> {
  if (role === "Admin_Full" || role === "Admin_Read") {
    return [];
  }
  const query = db.select({ storeName: storeReferenceTable.storeName })
    .from(storeReferenceTable);

  const conditions = [];
  if (month) conditions.push(eq(storeReferenceTable.month, month));
  if (year) conditions.push(eq(storeReferenceTable.year, year));
  if (role === "Operation_Manager" && assignedName) {
    conditions.push(eq(storeReferenceTable.operationManager, assignedName));
  } else if (role === "Operation_Consultant" && assignedName) {
    conditions.push(eq(storeReferenceTable.operationConsultant, assignedName));
  }
  const results = conditions.length > 0
    ? await query.where(and(...conditions))
    : await query;
  return results.map((r) => r.storeName);
}

router.get("/dashboard/kpis", requireAuth, async (req, res) => {
  const month = req.query.month ? parseInt(req.query.month as string) : undefined;
  const year = req.query.year ? parseInt(req.query.year as string) : undefined;
  const store = req.query.store as string | undefined;
  const { role, assignedName } = req.session as { role: string; assignedName: string | null };

  let targetMonth = month;
  let targetYear = year;

  if (!targetMonth || !targetYear) {
    const latest = await db
      .select({ month: activeEmployeesTable.month, year: activeEmployeesTable.year })
      .from(activeEmployeesTable)
      .orderBy(sql`${activeEmployeesTable.year} DESC, ${activeEmployeesTable.month} DESC`)
      .limit(1);
    if (latest[0]) {
      targetMonth = targetMonth ?? latest[0].month;
      targetYear = targetYear ?? latest[0].year;
    } else {
      const now = new Date();
      targetMonth = targetMonth ?? (now.getMonth() + 1);
      targetYear = targetYear ?? now.getFullYear();
    }
  }

  const accessibleStores = role === "Admin_Full" || role === "Admin_Read"
    ? null
    : await getAccessibleStores(role, assignedName ?? null, targetMonth, targetYear);

  const empConditions = [
    eq(activeEmployeesTable.month, targetMonth!),
    eq(activeEmployeesTable.year, targetYear!),
  ];
  if (store) empConditions.push(eq(activeEmployeesTable.store, store));
  else if (accessibleStores && accessibleStores.length > 0) {
    empConditions.push(sql`${activeEmployeesTable.store} = ANY(${accessibleStores})`);
  }

  const [headcountResult] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(activeEmployeesTable)
    .where(and(...empConditions));

  const resConditions = [
    eq(resignationsTable.month, targetMonth!),
    eq(resignationsTable.year, targetYear!),
  ];
  if (store) resConditions.push(eq(resignationsTable.store, store));
  else if (accessibleStores && accessibleStores.length > 0) {
    resConditions.push(sql`${resignationsTable.store} = ANY(${accessibleStores})`);
  }

  const [resResult] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(resignationsTable)
    .where(and(...resConditions));

  const totalHeadcount = headcountResult?.count ?? 0;
  const totalResignations = resResult?.count ?? 0;

  const prevMonth = targetMonth! === 1 ? 12 : targetMonth! - 1;
  const prevYear = targetMonth! === 1 ? targetYear! - 1 : targetYear!;
  const prevConditions = [
    eq(activeEmployeesTable.month, prevMonth!),
    eq(activeEmployeesTable.year, prevYear!),
  ];
  if (store) prevConditions.push(eq(activeEmployeesTable.store, store));
  else if (accessibleStores && accessibleStores.length > 0) {
    prevConditions.push(sql`${activeEmployeesTable.store} = ANY(${accessibleStores})`);
  }

  const prevEmployees = await db
    .select({ employeeId: activeEmployeesTable.employeeId })
    .from(activeEmployeesTable)
    .where(and(...prevConditions));

  const currEmployees = await db
    .select({ employeeId: activeEmployeesTable.employeeId })
    .from(activeEmployeesTable)
    .where(and(...empConditions));

  const prevIds = new Set(prevEmployees.map((e) => e.employeeId));
  const newHires = currEmployees.filter((e) => !prevIds.has(e.employeeId)).length;

  const turnoverRate = totalHeadcount > 0 ? Math.round((totalResignations / totalHeadcount) * 100 * 100) / 100 : 0;

  res.json({
    totalHeadcount,
    newHires,
    totalResignations,
    turnoverRate,
    month: targetMonth,
    year: targetYear,
  });
});

router.get("/dashboard/turnover-by-job-title", requireAuth, async (req, res) => {
  const month = req.query.month ? parseInt(req.query.month as string) : undefined;
  const year = req.query.year ? parseInt(req.query.year as string) : undefined;
  const store = req.query.store as string | undefined;
  const { role, assignedName } = req.session as { role: string; assignedName: string | null };

  const accessibleStores = role === "Admin_Full" || role === "Admin_Read"
    ? null
    : await getAccessibleStores(role, assignedName ?? null, month, year);

  const conditions = [];
  if (month) conditions.push(eq(resignationsTable.month, month));
  if (year) conditions.push(eq(resignationsTable.year, year));
  if (store) conditions.push(eq(resignationsTable.store, store));
  else if (accessibleStores && accessibleStores.length > 0) {
    conditions.push(sql`${resignationsTable.store} = ANY(${accessibleStores})`);
  }

  const results = await db
    .select({
      label: resignationsTable.jobTitle,
      value: sql<number>`count(*)::int`,
    })
    .from(resignationsTable)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .groupBy(resignationsTable.jobTitle)
    .orderBy(sql`count(*) DESC`);

  res.json(results);
});

router.get("/dashboard/turnover-by-tenure", requireAuth, async (req, res) => {
  const month = req.query.month ? parseInt(req.query.month as string) : undefined;
  const year = req.query.year ? parseInt(req.query.year as string) : undefined;
  const store = req.query.store as string | undefined;
  const { role, assignedName } = req.session as { role: string; assignedName: string | null };

  const accessibleStores = role === "Admin_Full" || role === "Admin_Read"
    ? null
    : await getAccessibleStores(role, assignedName ?? null, month, year);

  const conditions = [];
  if (month) conditions.push(eq(resignationsTable.month, month));
  if (year) conditions.push(eq(resignationsTable.year, year));
  if (store) conditions.push(eq(resignationsTable.store, store));
  else if (accessibleStores && accessibleStores.length > 0) {
    conditions.push(sql`${resignationsTable.store} = ANY(${accessibleStores})`);
  }

  const resignations = await db
    .select({ hireDate: resignationsTable.hireDate, resignationDate: resignationsTable.resignationDate })
    .from(resignationsTable)
    .where(conditions.length > 0 ? and(...conditions) : undefined);

  const buckets: Record<string, number> = {
    "<3m": 0,
    "3-6m": 0,
    "6-12m": 0,
    ">1y": 0,
  };

  for (const r of resignations) {
    if (!r.hireDate) { buckets[">1y"]++; continue; }
    const hire = new Date(r.hireDate);
    const resign = r.resignationDate ? new Date(r.resignationDate) : new Date();
    const months = (resign.getFullYear() - hire.getFullYear()) * 12 + (resign.getMonth() - hire.getMonth());
    if (months < 3) buckets["<3m"]++;
    else if (months < 6) buckets["3-6m"]++;
    else if (months < 12) buckets["6-12m"]++;
    else buckets[">1y"]++;
  }

  res.json(Object.entries(buckets).map(([label, value]) => ({ label, value })));
});

router.get("/dashboard/gender-breakdown", requireAuth, async (req, res) => {
  const month = req.query.month ? parseInt(req.query.month as string) : undefined;
  const year = req.query.year ? parseInt(req.query.year as string) : undefined;
  const store = req.query.store as string | undefined;
  const { role, assignedName } = req.session as { role: string; assignedName: string | null };

  const accessibleStores = role === "Admin_Full" || role === "Admin_Read"
    ? null
    : await getAccessibleStores(role, assignedName ?? null, month, year);

  const conditions = [];
  if (month) conditions.push(eq(resignationsTable.month, month));
  if (year) conditions.push(eq(resignationsTable.year, year));
  if (store) conditions.push(eq(resignationsTable.store, store));
  else if (accessibleStores && accessibleStores.length > 0) {
    conditions.push(sql`${resignationsTable.store} = ANY(${accessibleStores})`);
  }

  const results = await db
    .select({
      label: resignationsTable.gender,
      value: sql<number>`count(*)::int`,
    })
    .from(resignationsTable)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .groupBy(resignationsTable.gender);

  res.json(results);
});

router.get("/dashboard/available-periods", requireAuth, async (_req, res) => {
  const periods = await db
    .selectDistinct({
      month: activeEmployeesTable.month,
      year: activeEmployeesTable.year,
    })
    .from(activeEmployeesTable)
    .orderBy(sql`${activeEmployeesTable.year} DESC, ${activeEmployeesTable.month} DESC`);
  res.json(periods);
});

export default router;
