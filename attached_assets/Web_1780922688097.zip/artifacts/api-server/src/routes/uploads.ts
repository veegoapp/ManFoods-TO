import { Router } from "express";
import multer from "multer";
import * as XLSX from "xlsx";
import { db, activeEmployeesTable, resignationsTable, storeReferenceTable, uploadLogsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireRole } from "../middlewares/auth";
import { logger } from "../lib/logger";

const router = Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });

function safeDate(val: unknown): string | null {
  if (!val) return null;
  if (val instanceof Date) return val.toISOString().split("T")[0];
  if (typeof val === "number") {
    try {
      const d = XLSX.SSF.parse_date_code(val);
      return `${d.y}-${String(d.m).padStart(2, "0")}-${String(d.d).padStart(2, "0")}`;
    } catch {
      return null;
    }
  }
  if (typeof val === "string" && val.trim()) {
    const d = new Date(val);
    if (!isNaN(d.getTime())) return d.toISOString().split("T")[0];
  }
  return null;
}

function normalize(val: unknown): string {
  if (val === null || val === undefined) return "";
  return String(val).trim();
}

router.post(
  "/uploads/active-employees",
  requireRole("Admin_Full", "Admin_Read"),
  upload.single("file"),
  async (req, res) => {
    if (!req.file) { res.status(400).json({ error: "No file uploaded" }); return; }
    const month = parseInt(req.body.month);
    const year = parseInt(req.body.year);
    if (!month || !year) { res.status(400).json({ error: "month and year are required" }); return; }

    try {
      const wb = XLSX.read(req.file.buffer, { type: "buffer", cellDates: true });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(ws, { defval: "" });

      await db.delete(activeEmployeesTable).where(
        and(eq(activeEmployeesTable.month, month), eq(activeEmployeesTable.year, year))
      );

      const records = rows.map((r) => ({
        month,
        year,
        employeeId: normalize(r["Employee ID"] ?? r["EmployeeID"] ?? r["employee_id"] ?? r["ID"] ?? r["id"]),
        name: normalize(r["Name"] ?? r["Employee Name"] ?? r["name"]),
        store: normalize(r["Store"] ?? r["store"]),
        jobTitle: normalize(r["Job Title"] ?? r["JobTitle"] ?? r["Position"] ?? r["job_title"]),
        grade: normalize(r["Grade"] ?? r["grade"] ?? ""),
        payrollGroup: normalize(r["Payroll Group"] ?? r["PayrollGroup"] ?? r["payroll_group"] ?? ""),
        costCenter: normalize(r["Cost Center"] ?? r["CostCenter"] ?? r["cost_center"] ?? ""),
        gender: normalize(r["Gender"] ?? r["gender"] ?? ""),
        hireDate: safeDate(r["Hire Date"] ?? r["HireDate"] ?? r["hire_date"] ?? r["Join Date"]),
      })).filter((r) => r.employeeId || r.name);

      if (records.length > 0) {
        await db.insert(activeEmployeesTable).values(records);
      }

      await db.insert(uploadLogsTable).values({
        fileType: "active_employees",
        fileName: req.file.originalname,
        month,
        year,
        uploadedBy: req.session.email ?? "unknown",
      });

      res.json({ success: true, message: `Processed ${records.length} records`, rowsProcessed: records.length });
    } catch (err) {
      logger.error({ err }, "Failed to process active employees upload");
      res.status(500).json({ error: "Failed to process file" });
    }
  }
);

router.post(
  "/uploads/resignations",
  requireRole("Admin_Full", "Admin_Read"),
  upload.single("file"),
  async (req, res) => {
    if (!req.file) { res.status(400).json({ error: "No file uploaded" }); return; }
    const month = parseInt(req.body.month);
    const year = parseInt(req.body.year);
    if (!month || !year) { res.status(400).json({ error: "month and year are required" }); return; }

    try {
      const wb = XLSX.read(req.file.buffer, { type: "buffer", cellDates: true });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(ws, { defval: "" });

      await db.delete(resignationsTable).where(
        and(eq(resignationsTable.month, month), eq(resignationsTable.year, year))
      );

      const records = rows.map((r) => ({
        month,
        year,
        employeeId: normalize(r["Employee ID"] ?? r["EmployeeID"] ?? r["employee_id"] ?? r["ID"] ?? ""),
        name: normalize(r["Name"] ?? r["Employee Name"] ?? r["name"] ?? ""),
        store: normalize(r["Store"] ?? r["store"] ?? ""),
        jobTitle: normalize(r["Job Title"] ?? r["JobTitle"] ?? r["Position"] ?? r["job_title"] ?? ""),
        gender: normalize(r["Gender"] ?? r["gender"] ?? ""),
        hireDate: safeDate(r["Hire Date"] ?? r["HireDate"] ?? r["hire_date"] ?? r["Join Date"]),
        resignationDate: safeDate(r["Resignation Date"] ?? r["ResignationDate"] ?? r["resignation_date"] ?? r["Last Day"]),
        payrollGroup: normalize(r["Payroll Group"] ?? r["PayrollGroup"] ?? r["payroll_group"] ?? ""),
        costCenter: normalize(r["Cost Center"] ?? r["CostCenter"] ?? r["cost_center"] ?? ""),
      })).filter((r) => r.employeeId || r.name);

      if (records.length > 0) {
        await db.insert(resignationsTable).values(records);
      }

      await db.insert(uploadLogsTable).values({
        fileType: "resignations",
        fileName: req.file.originalname,
        month,
        year,
        uploadedBy: req.session.email ?? "unknown",
      });

      res.json({ success: true, message: `Processed ${records.length} records`, rowsProcessed: records.length });
    } catch (err) {
      logger.error({ err }, "Failed to process resignations upload");
      res.status(500).json({ error: "Failed to process file" });
    }
  }
);

router.post(
  "/uploads/store-reference",
  requireRole("Admin_Full", "Admin_Read"),
  upload.single("file"),
  async (req, res) => {
    if (!req.file) { res.status(400).json({ error: "No file uploaded" }); return; }
    const month = parseInt(req.body.month);
    const year = parseInt(req.body.year);
    if (!month || !year) { res.status(400).json({ error: "month and year are required" }); return; }

    try {
      const wb = XLSX.read(req.file.buffer, { type: "buffer", cellDates: true });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(ws, { defval: "" });

      await db.delete(storeReferenceTable).where(
        and(eq(storeReferenceTable.month, month), eq(storeReferenceTable.year, year))
      );

      const records = rows.map((r) => ({
        month,
        year,
        storeName: normalize(r["Store Name"] ?? r["StoreName"] ?? r["Store"] ?? r["store_name"] ?? ""),
        storeLeader: normalize(r["Store Leader"] ?? r["StoreLeader"] ?? r["store_leader"] ?? ""),
        operationConsultant: normalize(r["Operation Consultant"] ?? r["OperationConsultant"] ?? r["OC"] ?? r["Consultant"] ?? ""),
        operationManager: normalize(r["Operation Manager"] ?? r["OperationManager"] ?? r["OM"] ?? r["Manager"] ?? ""),
      })).filter((r) => r.storeName);

      if (records.length > 0) {
        await db.insert(storeReferenceTable).values(records);
      }

      await db.insert(uploadLogsTable).values({
        fileType: "store_reference",
        fileName: req.file.originalname,
        month,
        year,
        uploadedBy: req.session.email ?? "unknown",
      });

      res.json({ success: true, message: `Processed ${records.length} records`, rowsProcessed: records.length });
    } catch (err) {
      logger.error({ err }, "Failed to process store reference upload");
      res.status(500).json({ error: "Failed to process file" });
    }
  }
);

router.get("/uploads/logs", requireRole("Admin_Full", "Admin_Read"), async (_req, res) => {
  const logs = await db.select().from(uploadLogsTable).orderBy(uploadLogsTable.uploadDate);
  res.json(logs.map((l) => ({
    id: l.id,
    fileType: l.fileType,
    fileName: l.fileName,
    month: l.month,
    year: l.year,
    uploadDate: l.uploadDate.toISOString(),
    uploadedBy: l.uploadedBy,
  })).reverse());
});

router.delete("/uploads/logs/:id", requireRole("Admin_Full"), async (req, res) => {
  const id = parseInt(String(req.params.id));
  const [log] = await db.select().from(uploadLogsTable).where(eq(uploadLogsTable.id, id)).limit(1);
  if (!log) { res.status(404).json({ error: "Not found" }); return; }

  if (log.fileType === "active_employees") {
    await db.delete(activeEmployeesTable).where(
      and(eq(activeEmployeesTable.month, log.month), eq(activeEmployeesTable.year, log.year))
    );
  } else if (log.fileType === "resignations") {
    await db.delete(resignationsTable).where(
      and(eq(resignationsTable.month, log.month), eq(resignationsTable.year, log.year))
    );
  } else if (log.fileType === "store_reference") {
    await db.delete(storeReferenceTable).where(
      and(eq(storeReferenceTable.month, log.month), eq(storeReferenceTable.year, log.year))
    );
  }

  await db.delete(uploadLogsTable).where(eq(uploadLogsTable.id, id));
  res.status(204).send();
});

export default router;
