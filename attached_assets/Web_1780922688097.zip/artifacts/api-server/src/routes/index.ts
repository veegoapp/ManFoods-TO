import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import usersRouter from "./users";
import dashboardRouter from "./dashboard";
import uploadsRouter from "./uploads";
import employeesRouter from "./employees";
import storesRouter from "./stores";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(usersRouter);
router.use(dashboardRouter);
router.use(uploadsRouter);
router.use(employeesRouter);
router.use(storesRouter);

export default router;
