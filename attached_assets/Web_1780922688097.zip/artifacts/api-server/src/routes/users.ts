import { Router } from "express";
import bcrypt from "bcryptjs";
import { db, usersTable, storeReferenceTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth, requireRole } from "../middlewares/auth";

const router = Router();

const ADMIN_ROLES = ["Admin_Full", "Admin_Read"];

router.get("/users", requireRole("Admin_Full", "Admin_Read"), async (_req, res) => {
  const users = await db
    .select({
      id: usersTable.id,
      email: usersTable.email,
      role: usersTable.role,
      assignedName: usersTable.assignedName,
      createdAt: usersTable.createdAt,
    })
    .from(usersTable)
    .orderBy(usersTable.createdAt);
  res.json(users.map((u) => ({ ...u, assignedName: u.assignedName ?? null })));
});

router.get("/users/assignable-names", requireRole("Admin_Full", "Admin_Read"), async (_req, res) => {
  const stores = await db
    .select({
      operationManager: storeReferenceTable.operationManager,
      operationConsultant: storeReferenceTable.operationConsultant,
    })
    .from(storeReferenceTable);

  const managersSet = new Set<string>();
  const consultantsSet = new Set<string>();
  for (const s of stores) {
    if (s.operationManager) managersSet.add(s.operationManager);
    if (s.operationConsultant) consultantsSet.add(s.operationConsultant);
  }
  res.json({
    operationManagers: Array.from(managersSet).sort(),
    operationConsultants: Array.from(consultantsSet).sort(),
  });
});

router.post("/users", requireRole("Admin_Full"), async (req, res) => {
  const { email, password, role, assignedName } = req.body as {
    email: string;
    password: string;
    role: string;
    assignedName?: string | null;
  };
  if (!email || !password || !role) {
    res.status(400).json({ error: "email, password, and role are required" });
    return;
  }
  const passwordHash = bcrypt.hashSync(password, 10);
  const [user] = await db
    .insert(usersTable)
    .values({ email: email.toLowerCase(), passwordHash, role, assignedName: assignedName ?? null })
    .returning();
  res.status(201).json({ id: user.id, email: user.email, role: user.role, assignedName: user.assignedName ?? null, createdAt: user.createdAt.toISOString() });
});

router.get("/users/:id", requireRole("Admin_Full", "Admin_Read"), async (req, res) => {
  const id = parseInt(String(req.params.id));
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, id)).limit(1);
  if (!user) { res.status(404).json({ error: "Not found" }); return; }
  res.json({ id: user.id, email: user.email, role: user.role, assignedName: user.assignedName ?? null, createdAt: user.createdAt.toISOString() });
});

router.patch("/users/:id", requireRole("Admin_Full"), async (req, res) => {
  const id = parseInt(String(req.params.id));
  const { email, password, role, assignedName } = req.body as {
    email?: string;
    password?: string | null;
    role?: string;
    assignedName?: string | null;
  };
  const updates: Record<string, unknown> = {};
  if (email) updates.email = email.toLowerCase();
  if (password) updates.passwordHash = bcrypt.hashSync(password, 10);
  if (role) updates.role = role;
  if (assignedName !== undefined) updates.assignedName = assignedName;
  if (Object.keys(updates).length === 0) {
    res.status(400).json({ error: "No fields to update" });
    return;
  }
  const [user] = await db.update(usersTable).set(updates).where(eq(usersTable.id, id)).returning();
  if (!user) { res.status(404).json({ error: "Not found" }); return; }
  res.json({ id: user.id, email: user.email, role: user.role, assignedName: user.assignedName ?? null, createdAt: user.createdAt.toISOString() });
});

router.delete("/users/:id", requireRole("Admin_Full"), async (req, res) => {
  const id = parseInt(String(req.params.id));
  await db.delete(usersTable).where(eq(usersTable.id, id));
  res.status(204).send();
});

export default router;
