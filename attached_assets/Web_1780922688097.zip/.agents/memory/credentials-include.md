---
  name: credentials include for session auth
  description: The custom fetch wrapper must pass credentials:"include" for session-based auth to work in the browser
  ---

  ## Rule
  All API fetch calls must include `credentials: "include"` so the browser sends the session cookie.

  **Why:** Without this, the browser strips cookies from cross-origin or same-site proxied requests, causing every API call after login to return 401 even though the session exists on the server.

  **How to apply:** In `lib/api-client-react/src/custom-fetch.ts`, ensure the `fetch()` call includes:
  ```ts
  credentials: init.credentials ?? "include"
  ```
  