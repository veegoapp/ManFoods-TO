---
  name: connect-pg-simple session table fix
  description: How to handle the broken createTableIfMissing in bundled express-session + connect-pg-simple setups
  ---

  ## Rule
  Never use `createTableIfMissing: true` in the `connect-pg-simple` store config when the server is bundled with esbuild. Instead, create the session table manually with a raw SQL query at server startup.

  **Why:** esbuild bundles the app into `dist/index.mjs`, and `connect-pg-simple` tries to read `table.sql` relative to the CWD (which becomes `dist/`). The file doesn't exist there, so the table is never created, sessions fail to persist, and every request after login returns 401.

  **How to apply:** In `index.ts` (the server entry point), import `pool` from the DB package and run:
  ```ts
  await client.query(`CREATE TABLE IF NOT EXISTS "session" (...)`);
  ```
  before `app.listen()`. Set `createTableIfMissing: false` in the store options.
  