# Manfoods Workforce Analytics

HR analytics system for tracking employee turnover and workforce movements via monthly Excel uploads.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080, serves /api)
- `pnpm --filter @workspace/manfoods-dashboard run dev` — run the frontend (port 21112, serves /)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string, `SESSION_SECRET` — session signing secret

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5 + express-session (PostgreSQL session store)
- DB: PostgreSQL + Drizzle ORM
- Auth: Session-based (bcryptjs password hashing)
- Excel parsing: xlsx (ExcelDataReader equivalent)
- Frontend: React + Vite + Tailwind CSS + Recharts + wouter
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/api-spec/openapi.yaml` — API contract source of truth
- `lib/db/src/schema/` — Database schema (users, active-employees, resignations, store-reference, upload-logs)
- `artifacts/api-server/src/routes/` — Express route handlers (auth, users, dashboard, uploads, employees, stores)
- `artifacts/api-server/src/middlewares/auth.ts` — Session auth middleware + role check
- `artifacts/manfoods-dashboard/src/` — React frontend

## Architecture decisions

- Session-based auth using `express-session` + `connect-pg-simple` (no JWT needed for internal tool)
- Role-based access: Admin_Full/Admin_Read see all data; OM/OC see only their assigned stores
- Store Reference snapshots (by month/year) enable tracking leadership changes over time
- Excel uploads replace existing data for that month/year pair (idempotent re-uploads)
- `retry: false` on the `/auth/me` query prevents double-401 delays on page load

## Product

- Login → role-based redirect (admin to `/admin/analytics`, OM/OC to `/dashboard`)
- Dashboard: KPI cards (headcount, hires, resignations, turnover %) + charts (job title, tenure, gender) + AI placeholder
- Admin: Global analytics, Excel uploads, user management (CRUD), turnover analysis (placeholder), reports (placeholder)
- Data flow: Upload Excel → parse with xlsx → store by month/year → query via API filters

## User preferences

_Populate as you build._

## Gotchas

- Always restart the API server workflow after changing route files (it builds from source)
- The `xlsx` library's `XLSX.SSF.parse_date_code` handles Excel serial date numbers
- Column header names in Excel are normalized with flexible matching (supports various casings)
- Session table is created manually at startup in `index.ts` via raw SQL (`CREATE TABLE IF NOT EXISTS "session" ...`) — `connect-pg-simple`'s `createTableIfMissing: true` fails in bundled dist because it can't find its `table.sql` file by relative path
- `customFetch` in `lib/api-client-react/src/custom-fetch.ts` uses `credentials: "include"` for all requests so browser session cookies are sent — critical for session-based auth
- Run codegen after any OpenAPI spec change: `pnpm --filter @workspace/api-spec run codegen`
- Sample Excel test files live at `samples/` (active-employees-may-2026.xlsx, resignations-may-2026.xlsx, store-reference-may-2026.xlsx)

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
- Default admin credentials: `admin@manfoods.com` / `admin123`
